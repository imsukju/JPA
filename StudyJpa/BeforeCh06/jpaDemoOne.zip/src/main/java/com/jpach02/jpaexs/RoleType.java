package com.jpach02.jpaexs;

public enum RoleType 
{
	Guest ,User, Admin
}
