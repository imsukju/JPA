package com.jpaorphan.jpaexs;

public enum EntityClassStyle {
	CUSTOMER,ORDER,LINEITEM
}
